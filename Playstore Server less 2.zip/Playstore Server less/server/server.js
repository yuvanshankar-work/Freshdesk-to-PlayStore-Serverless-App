const { JWT } = require('google-auth-library');

const SCHEDULE_NAME = 'fetch_playstore_reviews';

function handleResponse(err, resp) {
  if (!err && resp.statusCode === 200) {
    console.log(JSON.stringify({
      status: resp.statusCode,
      message: 'success'
    }));
  }
}

// ── Pure-JS base64 (no Buffer / btoa needed in Freshworks runtime) ──────────
function base64Encode(str) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let encoded = '', i = 0;
  while (i < str.length) {
    const c1 = str.charCodeAt(i++), c2 = str.charCodeAt(i++), c3 = str.charCodeAt(i++);
    encoded += chars[c1>>2] + chars[((c1&3)<<4)|(c2>>4)]
             + chars[isNaN(c2)?64:(((c2&15)<<2)|(c3>>6))]
             + chars[isNaN(c3)?64:(c3&63)];
  }
  return encoded;
}

// ── $db helpers ─────────────────────────────────────────────────────────────
function parseConfigJson(data) {
  try {
    return typeof data === 'string' ? JSON.parse(data) : data;
  } catch {
    return null;
  }
}

/**
 * Reads installation config from $db (stored by iparams.html via client.db.set).
 * This is the fix for scheduled events where args.iparams is always {}.
 */
async function getConfigFromDb() {
  try {
    const data = await $db.get('fw_config');
    const cfg = parseConfigJson(data);
    if (cfg && cfg.apiKey && cfg.domain) {
      console.log('Config loaded from $db. Domain:', cfg.domain);
      return cfg;
    }
  } catch (dbErr) {
    console.log('$db.get fw_config miss:', dbErr && dbErr.message || dbErr);
  }
  return null;
}

/**
 * Saves config to $db from onAppInstall / afterAppUpdate when iparams are available.
 */
async function saveConfigToDb(iparams) {
  if (!iparams || !iparams.apiKey || !iparams.domain) return;
  try {
    const configObj = typeof iparams === 'string' ? JSON.parse(iparams) : iparams;
    await $db.set('fw_config', configObj);
    console.log('Config saved to $db. Domain:', configObj.domain);
  } catch (err) {
    console.log('$db.set fw_config failed:', err.message || err);
  }
}

// ── Credential resolution (iparams → $db → error) ────────────────────────
/**
 * Returns a resolved iparams object, trying args.iparams first,
 * then falling back to $db (which was stored by iparams.html / install handler).
 */
function isValidConfig(cfg) {
  return Boolean(cfg && cfg.apiKey && cfg.domain);
}

function extractArgsConfig(args) {
  if (!args) return null;
  if (isValidConfig(args.iparams)) return args.iparams;
  if (args.data && isValidConfig(args.data.config)) return args.data.config;
  return null;
}

async function resolveConfig(args) {
  const fromArgs = extractArgsConfig(args);
  if (fromArgs) return fromArgs;
  const fromDb = await getConfigFromDb();
  if (fromDb) return fromDb;
  console.error('No valid Freshdesk config found in args or $db. Aborting.');
  return null;
}

// ── Service-account helpers ───────────────────────────────────────────────
function parseServiceAccount(sa) {
  if (!sa) return null;
  if (typeof sa === 'string') { try { return JSON.parse(sa); } catch { return null; } }
  return sa;
}

function getServiceAccountCredentials(cfg) {
  const sa = parseServiceAccount(cfg && cfg.serviceAccount);
  if (sa && sa.client_email && sa.private_key) {
    console.log(`Using Service Account credentials from installation settings (client_email: ${sa.client_email}, project: ${sa.project_id || 'N/A'})`);
    return sa;
  }
  console.warn('No valid Service Account credentials found in installation settings. Please check your App Setup configuration in Freshdesk.');
  return null;
}

// ── Freshdesk helpers ─────────────────────────────────────────────────────
function getDomain(cfg) {
  return (cfg && cfg.domain || '').replace(/^https?:\/\//, '').split('/')[0];
}

function getApiKey(cfg) {
  return (cfg && cfg.apiKey) || '';
}

function getAuthHeader(cfg) {
  const key = getApiKey(cfg);
  if (!key) return '';
  return `Basic ${base64Encode(`${key}:X`)}`;
}

function getPackageName(cfg) {
  return String((cfg && cfg.packageName) || '').trim().replace(/[./]+$/, '');
}

// ── Google access token ───────────────────────────────────────────────────
async function getAccessToken(cfg) {
  const sa = getServiceAccountCredentials(cfg);
  if (!sa || !sa.client_email || !sa.private_key) {
    console.error('Service Account credentials missing.');
    return null;
  }
  try {
    const client = new JWT({
      email: sa.client_email,
      key: sa.private_key.replace(/\\n/g, '\n'),
      scopes: ['https://www.googleapis.com/auth/androidpublisher'],
    });
    const tokenResp = await client.getAccessToken();
    console.log('Access Token obtained');
    return tokenResp.token;
  } catch (err) {
    console.error('Error fetching access token:', err);
    throw err;
  }
}

// ── Contact creation ──────────────────────────────────────────────────────
function extractExistingContactId(errRes) {
  const errors = errRes && errRes.errors;
  const info = errors && errors[0] && errors[0].additional_info;
  return info && info.user_id;
}

function handleContactError(err) {
  try {
    const errRes = JSON.parse(err.response);
    const existingId = extractExistingContactId(errRes);
    if (existingId) {
      console.log('Contact already exists, ID:', existingId);
      return { id: existingId };
    }
  } catch (parseErr) { console.log('Contact parse err:', parseErr && parseErr.message); }
  throw err;
}

async function createContactForReview(authorName, reviewId, cfg) {
  const payload = { name: `${authorName} - PlayStore Contact`, unique_external_id: reviewId };
  console.log('Contact payload:', JSON.stringify(payload));
  const options = {
    context: { domain: getDomain(cfg), authHeader: getAuthHeader(cfg) },
    iparams: {},
    body: JSON.stringify(payload)
  };
  try {
    const { response } = await $request.invokeTemplate('createContact', options);
    return JSON.parse(response);
  } catch (err) {
    return handleContactError(err);
  }
}

// ── Ticket helpers ────────────────────────────────────────────────────────
function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function nlToBr(str) {
  return escapeHtml(str).replace(/\n/g, "<br/>");
}

function truncate(str, max) {
  if (!str || str.length <= max) return str || "";
  return str.slice(0, max - 3) + "...";
}

function slugify(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 30);
}

function splitGoogleText(raw) {
  const parts = String(raw || "").split("\t");
  if (parts.length > 1) {
    return { title: parts[0].trim(), text: parts.slice(1).join(" ").trim() };
  }
  return { title: "", text: (parts[0] || "").trim() };
}

function formatGoogleDate(lastModified) {
  if (lastModified && lastModified.seconds) {
    return new Date(Number(lastModified.seconds) * 1000).toISOString();
  }
  return new Date().toISOString();
}

function buildDescriptionLine(label, value) {
  if (!value) return "";
  return "<p><strong>" + escapeHtml(label) + ":</strong> " + nlToBr(value) + "</p>";
}

function formatRating(starRating) {
  return `${starRating} ${starRating > 1 ? 'stars' : 'star'}`;
}

function getDeviceName(userComment) {
  return (userComment.deviceMetadata && userComment.deviceMetadata.productName) || '';
}

function buildFieldMappings(userComment, reviewId, ip) {
  const formattedReviewId = String(reviewId).startsWith('g-') ? reviewId : `g-${reviewId}`;
  const mappings = [
    { key: ip.field_review_type || 'cf_review_type', val: 'Google Play Store' },
    { key: ip.field_review_rating || 'cf_review_rating', val: formatRating(userComment.starRating) },
    { key: ip.field_device_name || 'cf_device_name', val: getDeviceName(userComment) },
    { key: ip.field_reviewid || 'cf_reviewid', val: formattedReviewId }
  ];
  return mappings;
}

function buildCustomFields(userComment, reviewId, cfg) {
  const ip = cfg || {};
  const fields = {};
  buildFieldMappings(userComment, reviewId, ip).forEach(function(m) {
    // Only accept genuine custom fields starting with cf_ (filters out 'description' or standard fields)
    if (m.key && m.key.startsWith('cf_') && m.key !== 'none') {
      fields[m.key] = m.val;
    }
  });
  return fields;
}

function buildSubject(uc, appName) {
  const rating = `${uc.starRating}/5`;
  const content = splitGoogleText(uc.text);
  const detail = content.title || truncate(content.text || uc.text || "", 80) || "No comment";
  const raw = `[Google Play] ${rating} - ${appName} - ${detail}`;
  return truncate(raw, 200);
}

function formatReviewId(reviewId) {
  return String(reviewId).startsWith('g-') ? reviewId : `g-${reviewId}`;
}

function getDeveloperReplyText(dc) {
  return (dc && dc.text) || '';
}

function buildTicketDescription(uc, authorName, reviewId, appLabel, dc) {
  const content = splitGoogleText(uc.text);
  const parts = [
    buildDescriptionLine("Store", "Google Play"),
    buildDescriptionLine("App", appLabel),
    buildDescriptionLine("Rating", `${uc.starRating} / 5`),
    buildDescriptionLine("Reviewer", authorName || "Anonymous"),
    buildDescriptionLine("Review date", formatGoogleDate(uc.lastModified)),
    buildDescriptionLine("App version", uc.appVersionName),
    buildDescriptionLine("Title", content.title),
    buildDescriptionLine("Review", content.text || uc.text || "(no text)"),
    buildDescriptionLine("Developer reply on the store", getDeveloperReplyText(dc)),
    buildDescriptionLine("Review ID", formatReviewId(reviewId))
  ];
  return parts.filter(Boolean).join("");
}

function buildTags(starRating, appName) {
  const appSlug = slugify(appName);
  const ratingTag = "rating-" + (Number(starRating) || 0);
  const tags = ["app-review", "google-play"];
  if (appSlug) tags.push(appSlug);
  tags.push(ratingTag);
  return tags;
}

function buildTicketPayload(requesterId, authorName, reviewId, comment, cfg, dc) {
  const uc = comment.userComment;
  const appName = (cfg && cfg.appName) || "Village Meat";
  const appDivision = (cfg && cfg.appDivision) || "EasyDaily";
  const appLabel = appDivision ? `${appDivision} / ${appName}` : appName;

  return {
    requester_id: requesterId,
    subject: buildSubject(uc, appName),
    description: buildTicketDescription(uc, authorName, reviewId, appLabel, dc),
    status: 2,
    priority: uc.starRating <= 2 ? 3 : 2,
    tags: buildTags(uc.starRating, appName),
    custom_fields: buildCustomFields(uc, reviewId, cfg)
  };
}

async function createTicketForComment(requesterId, authorName, reviewId, comment, cfg, dc) {
  if (!comment || !comment.userComment) return;
  const payload = buildTicketPayload(requesterId, authorName, reviewId, comment, cfg, dc);
  console.log('Creating ticket for:', authorName);
  const options = {
    context: { domain: getDomain(cfg), authHeader: getAuthHeader(cfg) },
    iparams: {},
    body: JSON.stringify(payload)
  };
  try {
    const { response } = await $request.invokeTemplate('createTicket', options);
    console.log('Ticket created:', response);
  } catch (err) {
    // Fallback: retry without custom fields
    console.error('Ticket create failed, retrying without custom_fields:', err);
    try {
      delete payload.custom_fields;
      options.body = JSON.stringify(payload);
      const { response } = await $request.invokeTemplate('createTicket', options);
      console.log('Fallback ticket created:', response);
    } catch (err2) {
      console.error('Fallback ticket also failed:', err2);
    }
  }
}

// ── Review deduplication helpers via $db ─────────────────────────────────
async function getProcessedReviewIds() {
  try {
    const record = await $db.get('synced_review_ids');
    if (record && Array.isArray(record.ids)) return record.ids;
  } catch {
    // miss in db
  }
  return [];
}

async function markReviewProcessed(reviewId) {
  if (!reviewId) return;
  try {
    const ids = await getProcessedReviewIds();
    if (!ids.includes(reviewId)) {
      const updated = [reviewId, ...ids].slice(0, 100);
      await $db.set('synced_review_ids', { ids: updated });
      console.log('Marked review as synced in $db:', reviewId);
    }
  } catch (err) {
    console.log('Failed to mark review in $db:', err && err.message || err);
  }
}

// ── Review processing ─────────────────────────────────────────────────────
async function processSingleReview(review, cfg) {
  try {
    const { comments = [], authorName, reviewId } = review;
    const contact = await createContactForReview(authorName, reviewId, cfg);
    const dc = comments.map(function(c) { return c && c.developerComment; }).find(Boolean);
    for (const comment of comments) {
      if (comment && comment.userComment) {
        await createTicketForComment(contact.id, authorName, reviewId, comment, cfg, dc);
      }
    }
    // Mark as processed in $db to guarantee no duplicate tickets
    await markReviewProcessed(reviewId);
  } catch (err) {
    console.error('Error processing review:', err);
  }
}

function getLastSyncedReviewId(tickets, fieldReviewId) {
  if (!tickets || !tickets.length) return null;
  return tickets[0].custom_fields && tickets[0].custom_fields[fieldReviewId];
}

async function filterNewReviews(reviews, tickets, cfg) {
  const processedIds = await getProcessedReviewIds();
  const fieldReviewId = (cfg && cfg.field_reviewid) || 'cf_reviewid';
  const lastTicketId = getLastSyncedReviewId(tickets, fieldReviewId);

  return reviews.filter(function(r) {
    if (!r || !r.reviewId) return false;
    if (processedIds.includes(r.reviewId)) {
      console.log('Deduplication: Skipping already processed review (in $db):', r.reviewId);
      return false;
    }
    if (lastTicketId && r.reviewId === lastTicketId) {
      console.log('Deduplication: Skipping already processed review (matched last ticket):', r.reviewId);
      return false;
    }
    return true;
  });
}

// ── Scheduling ────────────────────────────────────────────────────────────
async function deleteSchedule() {
  try {
    await $schedule.delete({ name: SCHEDULE_NAME });
  } catch (delErr) {
    console.log('Schedule delete (expected if first run):', delErr && delErr.message);
  }
}

async function createSchedule(schedule_at) {
  try {
    const payload = { name: SCHEDULE_NAME };
    await $schedule.create({ name: SCHEDULE_NAME, data: payload, schedule_at });
    console.log('Schedule created successfully for:', schedule_at);
  } catch (err) {
    console.error('Schedule creation failed:', err);
  }
}

async function scheduleInitialRun() {
  const d = new Date();
  d.setMinutes(d.getMinutes() + 6);
  const schedule_at = d.toISOString();
  console.log('Initial schedule at:', schedule_at);
  await deleteSchedule();
  await createSchedule(schedule_at);
}

async function scheduleNextRun(scheduleAt) {
  await deleteSchedule();
  await createSchedule(scheduleAt);
}

// ── Core sync logic ───────────────────────────────────────────────────────
async function fetchAllReviews(token, cfg) {
  const { response } = await $request.invokeTemplate('getReview', {
    context: { token, packageName: getPackageName(cfg) },
    iparams: {}
  });
  return JSON.parse(response).reviews || [];
}

async function fetchFilteredTickets(cfg) {
  const fieldType = (cfg && cfg.field_review_type) || 'cf_review_type';
  try {
    const { response } = await $request.invokeTemplate('fillterTickets', {
      context: { domain: getDomain(cfg), authHeader: getAuthHeader(cfg), fieldType },
      iparams: {}
    });
    return JSON.parse(response).results || [];
  } catch (ticketErr) { console.log('Ticket filter error:', ticketErr && ticketErr.message); return []; }
}

async function syncReviews(token, cfg) {
  const apiKey = getApiKey(cfg);
  const domain = getDomain(cfg);

  if (!apiKey) {
    console.error('Freshdesk API key is missing. Cannot sync.');
    return;
  }
  if (!domain) {
    console.error('Freshdesk domain is missing. Cannot sync.');
    return;
  }

  console.log(`Syncing reviews for domain: ${domain}, API key ends in: ${apiKey.slice(-4)}`);
  const allReviews  = await fetchAllReviews(token, cfg);
  const tickets     = await fetchFilteredTickets(cfg);
  const newReviews  = await filterNewReviews(allReviews, tickets, cfg);
  console.log('New reviews to process:', newReviews.length);

  for (const review of newReviews) {
    await processSingleReview(review, cfg);
  }
}


// ── Conversation reply handler ────────────────────────────────────────────
function matchPlayStoreSubject(subject) {
  return typeof subject === 'string' && (subject.startsWith('[Google Play]') || subject.startsWith('PlayStore Review -'));
}

function isPlayStoreTicket(ticket, cfg) {
  if (!ticket) return false;
  if (matchPlayStoreSubject(ticket.subject)) return true;
  const cf = ticket.custom_fields;
  if (!cf) return false;
  const fieldType = (cfg && cfg.field_review_type) || 'cf_review_type';
  return cf[fieldType] === 'Google Play Store' || cf[fieldType] === 'Playstore';
}

function parseReviewIdFromText(text) {
  const match = String(text || '').match(/Review ID:\s*([a-zA-Z0-9_\-:]+)/i);
  return match ? match[1] : null;
}

function getReviewIdFromTicket(ticket, cfg) {
  if (!ticket) return null;
  const fieldId = (cfg && cfg.field_reviewid) || 'cf_reviewid';
  const cf = ticket.custom_fields;
  if (cf && cf[fieldId]) {
    return cf[fieldId];
  }
  return parseReviewIdFromText(ticket.description_text || ticket.description);
}

async function sendReplyToGoogle(token, reviewId, packageName, replyText) {
  const cleanId = String(reviewId).replace(/^g-/, '');
  try {
    const { response } = await $request.invokeTemplate('postReview', {
      context: { token, id: cleanId, packageName },
      iparams: {},
      body: JSON.stringify({ replyText })
    });
    console.log('Play Store reply successfully posted:', response);
  } catch (apiErr) {
    console.error('Error posting reply to Google Play Store:', apiErr && apiErr.message || apiErr);
  }
}

async function postPlayStoreReply(ticket, cfg, conversation) {
  const reviewId = getReviewIdFromTicket(ticket, cfg);
  if (!reviewId) {
    console.error('Cannot post Play Store reply: No review ID found in ticket custom_fields.');
    return;
  }

  const token = await getAccessToken(cfg);
  if (!token) return;

  const replyText = conversation.body_text || conversation.body || '';
  console.log(`Posting reply to Play Store (Review ID: ${reviewId})`);
  await sendReplyToGoogle(token, reviewId, getPackageName(cfg), replyText);
}

async function fetchTicketById(ticketId, cfg) {
  const { response: rawTicket } = await $request.invokeTemplate('getTicket', {
    context: { id: ticketId, domain: getDomain(cfg), authHeader: getAuthHeader(cfg) },
    iparams: {}
  });
  return JSON.parse(rawTicket);
}

function getPrivateConversation(args) {
  const conv = args && args.data && args.data.conversation;
  return (conv && conv.private) ? conv : null;
}

async function handleConversationReply(args) {
  const conversation = getPrivateConversation(args);
  if (!conversation) {
    console.log('Not a private conversation, skipping Play Store reply.');
    return;
  }
  const cfg = await resolveConfig(args);
  if (!cfg) return;

  try {
    const ticket = await fetchTicketById(conversation.ticket_id, cfg);
    if (isPlayStoreTicket(ticket, cfg)) {
      await postPlayStoreReply(ticket, cfg, conversation);
    } else {
      console.log('Not a Play Store ticket, skipping reply.');
    }
  } catch (err) {
    console.error('Error in handleConversationReply:', err && err.message || err);
  }
}

function extractDomain(opts) {
  return (opts && (opts.domain || opts.$domain || (opts.iparams && opts.iparams.domain))) || null;
}

function extractApiKey(opts) {
  return (opts && (opts.apiKey || (opts.iparams && opts.iparams.apiKey))) || null;
}

exports = {

  handleResponse: handleResponse,

  saveConfig: async function(options) {
    console.log('saveConfig SMI triggered');
    const domain = extractDomain(options);
    const apiKey = extractApiKey(options);
    const cfg = Object.assign({}, options, { domain, apiKey });

    if (!domain || !apiKey) {
      renderData({ status: 'error', message: 'Missing credentials' });
      return;
    }

    await saveConfigToDb(cfg);
    await scheduleInitialRun();
    renderData(null, { status: 'success' });
  },

  onAppInstallHandler: async function(args) {
    console.log('App installed. iparams received:', JSON.stringify(args && args.iparams));
    if (args && args.iparams && args.iparams.apiKey) {
      await saveConfigToDb(args.iparams);
    }
    await scheduleInitialRun();
    renderData();
  },

  afterAppUpdateHandler: async function(args) {
    console.log('App updated. iparams received:', JSON.stringify(args && args.iparams));
    if (args && args.iparams && args.iparams.apiKey) {
      await saveConfigToDb(args.iparams);
    }
    await scheduleInitialRun();
    renderData();
  },

  onScheduledEventHandler: async function(args) {
    console.log('Scheduled event triggered. Data:', JSON.stringify(args && args.data));

    const nextDate = new Date();
    nextDate.setMinutes(nextDate.getMinutes() + 6);
    const nextScheduleAt = nextDate.toISOString();

    try {
      const cfg = await resolveConfig(args);
      if (!cfg) {
        console.error('Aborting sync: no credentials available.');
      } else {
        const token = await getAccessToken(cfg);
        if (token) {
          await syncReviews(token, cfg);
        }
      }
    } catch (err) {
      console.error('Error in onScheduledEventHandler:', err);
    }

    await scheduleNextRun(nextScheduleAt);
  },

  onConversationCreateHandler: async function(args) {
    try {
      await handleConversationReply(args);
    } catch (err) {
      console.error('Error in onConversationCreateHandler:', err);
    }
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = exports;
}